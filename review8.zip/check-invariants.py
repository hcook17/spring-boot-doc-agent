#!/usr/bin/env python3
"""
Static invariants for the spring-signals pack. Runs without a CodeQL CLI.

WHY THIS EXISTS
Three documents quoted a "framework references in Catalog.qll" figure -- ~72,
then ~54 -- and neither reproduced under measurement (~42 with comments, ~37
without). The figure was doing rhetorical work in an architectural rationale
while nobody could re-derive it. A fourth hand-counted number would have been
the same defect with a different value.

So the numbers are computed here, the pattern is pinned in code, and the docs
cite this script rather than hardcoding results. If a doc and this script
disagree, the script is right by construction.

CHECKS
  1  or-or      no empty disjuncts (comments AND string literals stripped)
  2  layering   zero framework literals in java-signals-lib code
  3  location   Catalog.qll is not in the library pack
  4  wiring     MetaAnnotationEdges has a contributor in the query pack's
                import closure -- STRUCTURAL ONLY, see caveat below
  5  counts     measured framework-reference figures, both patterns

Exit 0 if all pass, 1 otherwise.

CAVEAT ON CHECK 4: this confirms the import and the subclass exist in source.
It cannot prove the contribution reaches `declaredMetaEdge` at evaluation time.
Only Probe.ql's `closed_state_restcontroller_is_controller > 0` proves that, and
it needs a database. A missing contribution produces NO compile error -- it
silently degrades `isOrMeta` to exact matching and reopens the @RestController
recall regression. Do not read a green check 4 as a closed gate.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / "codeql" / "packs" / "java-signals-lib"
PACK = ROOT / "codeql" / "packs" / "spring-signals"

# PINNED PATTERNS. Changing either changes every published figure, so change
# them in the same commit that updates the docs, and say so in the message.
#
# NARROW reproduces the four packages used in review verification, kept so
# figures stay comparable across reviews.
NARROW = re.compile(r"org\.springframework|javax\.persistence|org\.hibernate|io\.swagger")
# BROAD is the invariant pattern: anything naming a framework namespace.
BROAD = re.compile(
    r"org\.springframework|javax\.|jakarta\.|org\.hibernate|io\.swagger"
    r"|com\.fasterxml|tools\.jackson|com\.vladmihalcea|redis\.clients|io\.micrometer"
)


def strip_comments(text: str) -> str:
    """Remove QL block and line comments, preserving line structure."""
    text = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    return re.sub(r"//[^\n]*", "", text)


def strip_strings(text: str) -> str:
    """Remove double-quoted QL string literals, honouring backslash escapes."""
    return re.sub(r'"(?:\\.|[^"\\])*"', '""', text)


def ql_files(base: Path):
    return sorted(p for p in base.rglob("*.q*") if p.suffix in {".ql", ".qll"})


def check_or_or() -> list[str]:
    """
    Flag adjacent `or` tokens.

    Comments AND string literals must both go first. A raw `or\\s*//.*\\n\\s*or`
    regex false-positives on the ~20 legitimate `or` + explanatory-comment forms
    in this pack, and a comment-only strip still trips over `or` inside a regex
    literal. Tokenise, then look for `or` following `or`.
    """
    bad = []
    for f in ql_files(ROOT / "codeql"):
        toks = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", strip_strings(strip_comments(f.read_text())))
        for i in range(1, len(toks)):
            if toks[i] == "or" and toks[i - 1] == "or":
                bad.append(f"{f.relative_to(ROOT)}: adjacent 'or' at token {i}")
    return bad


def framework_hits(path: Path, pattern: re.Pattern, code_only: bool):
    text = strip_comments(path.read_text()) if code_only else path.read_text()
    occurrences = len(pattern.findall(text))
    lines = sum(1 for ln in text.splitlines() if pattern.search(ln))
    return occurrences, lines


def main() -> int:
    failures: list[str] = []

    print("1. or-or (empty disjuncts)")
    bad = check_or_or()
    if bad:
        failures += bad
        for b in bad:
            print("   FAIL", b)
    else:
        print("   PASS  0 adjacent 'or' tokens across all .ql/.qll")

    print("2. layering: framework literals in java-signals-lib code")
    total = 0
    for f in ql_files(LIB):
        occ, _ = framework_hits(f, BROAD, code_only=True)
        total += occ
        if occ:
            failures.append(f"{f.relative_to(ROOT)}: {occ} framework literals")
            print(f"   FAIL  {f.name}: {occ}")
    if not total:
        print("   PASS  0 (broad pattern, comments excluded)")

    print("3. location: Catalog.qll not in the library pack")
    if (LIB / "signals" / "Catalog.qll").exists():
        failures.append("Catalog.qll is in java-signals-lib")
        print("   FAIL  Catalog.qll found under java-signals-lib")
    else:
        print("   PASS  Catalog.qll lives in spring-signals")

    print("4. wiring (STRUCTURAL ONLY -- not a proof, see module docstring)")
    common = (PACK / "_Common.qll").read_text()
    edges = (PACK / "SpringMetaEdges.qll").read_text()
    probe = (PACK / "Probe.ql").read_text()
    for label, ok in [
        ("_Common imports SpringMetaEdges", "import SpringMetaEdges" in common),
        ("SpringMetaEdges extends MetaAnnotationEdges", "extends MetaAnnotationEdges" in edges),
        ("edge RestController -> Controller present", '"RestController"' in edges),
        ("Probe defines closed-state gate", "closed_state_restcontroller_is_controller" in probe),
    ]:
        print(f"   {'PASS' if ok else 'FAIL'}  {label}")
        if not ok:
            failures.append(label)
    print("   NOTE  runtime proof is Probe.ql on a real database; still unrun")

    print("5. measured framework references (pinned patterns)")
    print(f"   {'file':<26} {'narrow occ/line':>16} {'broad occ/line':>16}  (comments excluded)")
    for f in [PACK / "Catalog.qll", PACK / "SpringMetaEdges.qll"]:
        n_occ, n_ln = framework_hits(f, NARROW, code_only=True)
        b_occ, b_ln = framework_hits(f, BROAD, code_only=True)
        print(f"   {f.name:<26} {f'{n_occ}/{n_ln}':>16} {f'{b_occ}/{b_ln}':>16}")
    for f in [PACK / "Catalog.qll"]:
        n_occ, n_ln = framework_hits(f, NARROW, code_only=False)
        print(f"   {f.name + ' (with comments)':<26} {f'{n_occ}/{n_ln}':>16}")

    print()
    if failures:
        print(f"FAILED: {len(failures)} invariant violation(s)")
        return 1
    print("All static invariants hold. Wave 0 items 2-4 remain blocked on CodeQL CLI.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
